function Invoke-FormatFile
{
    Param (
        [Parameter(valuefrompipeline, mandatory)]
        [String]$FilePath,

        [String]$Settings = ('D:\Repos\AzureDeploymentFramework\PSScriptAnalyzerSettings.psd1')
    )
    Process 
    {
        Write-Verbose -Message "Formatting file: $($FilePath)" -Verbose
        $Text = Get-Content -Path $FilePath -Raw
        PsScriptAnalyzer\Invoke-Formatter -ScriptDefinition $Text -Settings $Settings |
            Set-Content -Path $FilePath
    }
}