function AutoCompleter
{
    Register-ArgumentCompleter -Native -CommandName winget -ScriptBlock {
        param($wordToComplete, $commandAst, $cursorPosition)
        [Console]::InputEncoding = [Console]::OutputEncoding = $OutputEncoding = [System.Text.Utf8Encoding]::new()
        $Local:word = $wordToComplete.Replace('"', '""')
        $Local:ast = $commandAst.ToString().Replace('"', '""')
        winget complete --word="$Local:word" --commandline "$Local:ast" --position $cursorPosition | ForEach-Object {
            [System.Management.Automation.CompletionResult]::new($_, $_, 'ParameterValue', $_)
        }
    }
    
    $scriptBlock = {
        param($commandName, $parameterName, $wordToComplete, $commandAst, $fakeBoundParameters)

        (Get-AzTemplateSpec) | ForEach-Object Name | Where-Object {
            $_ -like "$wordToComplete*"
        } | ForEach-Object {
            "'$_'"
        }
    }
    Register-ArgumentCompleter -CommandName Start-AzDeploy -ParameterName TemplateFile -ScriptBlock $scriptBlock
}