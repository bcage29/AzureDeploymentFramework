﻿Function Remove-MYAZVMInstanceResource
{
    [cmdletbinding(SupportsShouldProcess, ConfirmImpact = 'High')]
    Param (
        [parameter(mandatory)]
        [String]$ResourceGroup,
    
        # The VM name to remove, regex are supported
        [parameter(mandatory)]
        [String]$VMName
    )

    # Remove the VM's and then remove the datadisks, osdisk, NICs
    Get-AzVM -ResourceGroupName $ResourceGroup | Where-Object Name -Match $VMName | ForEach-Object {
        $a = $_
        $DataDisks = @($_.StorageProfile.DataDisks.Name)
        $OSDisk = @($_.StorageProfile.OSDisk.Name) 

        if ($pscmdlet.ShouldProcess("$($_.Name)", "Removing VM, Disks and NIC: $($_.Name)"))
        {
            Write-Warning -Message "Removing VM: $($_.Name)"
            $_ | Remove-AzVM -Force -Confirm:$false

            $_.NetworkProfile.NetworkInterfaces | ForEach-Object {
                $NICName = Split-Path -Path $_.ID -Leaf
                Write-Warning -Message "Removing NIC: $NICName"
                Get-AzNetworkInterface -ResourceGroupName $ResourceGroup -Name $NICName | Remove-AzNetworkInterface -Force
            }

            # Support to remove managed disks
            if ($a.StorageProfile.OsDisk.ManagedDisk )
            {
                ($DataDisks + $OSDisk) | ForEach-Object {
                    Write-Warning -Message "Removing Disk: $_"
                    Get-AzDisk -ResourceGroupName $ResourceGroup -DiskName $_ | Remove-AzDisk -Force
                }
            }
            # Support to remove unmanaged disks (from Storage Account Blob)
            else
            {
                # This assumes that OSDISK and DATADisks are on the same blob storage account
                # Modify the function if that is not the case.
                $saname = ($a.StorageProfile.OsDisk.Vhd.Uri -split '\.' | Select-Object -First 1) -split '//' | Select-Object -Last 1
                $sa = Get-AzStorageAccount -ResourceGroupName $ResourceGroup -Name $saname
        
                # Remove DATA disks
                $a.StorageProfile.DataDisks | ForEach-Object {
                    $disk = $_.Vhd.Uri | Split-Path -Leaf
                    Get-AzStorageContainer -Name vhds -Context $Sa.Context |
                        Get-AzStorageBlob -Blob $disk |
                        Remove-AzStorageBlob  
                    }
        
                    # Remove OSDisk disk
                    $disk = $a.StorageProfile.OsDisk.Vhd.Uri | Split-Path -Leaf
                    Get-AzStorageContainer -Name vhds -Context $Sa.Context |
                        Get-AzStorageBlob -Blob $disk |
                        Remove-AzStorageBlob  

                    }
            
                    # If you are on the network you can cleanup the Computer Account in AD            
                    # Get-ADComputer -Identity $a.OSProfile.ComputerName | Remove-ADObject -Recursive -confirm:$false
        
                }#PSCmdlet(ShouldProcess)
            }

        }