function cleantext
{
    Write-Verbose -Message 'I am your cleaning buttler, your text is clear sir!' -Verbose
    Get-ClipBoard | Set-ClipBoard
}
New-Alias -Name ct -Value cleantext