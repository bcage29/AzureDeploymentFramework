function azl
{
    param(
        [validateset('MSFT', 'MSDN', 'HAA')]
        [String]$Account,
        [Switch]$auth
    )

    $AZ = Switch ($Account)
    {
        'MSFT'
        {
            @{ 
                Name     = 'MSFT BENWILK AIRS'
                Id       = 'b8f402aa-20f7-4888-b45c-3cf086dad9c3'
                TenantId = '72f988bf-86f1-41af-91ab-2d7cd011db47'
                State    = 'Enabled'
            }
        }
        'MSDN'
        {
            @{ 
                Name     = 'Windows Azure MSDN - Visual Studio Ultimate'
                Id       = '1f0713fe-9b12-4c8f-ab0c-26aba7aaa3e5'
                TenantId = '3254f91d-4657-40df-962d-c8e6dad75963'
                State    = 'Enabled'
            }
        }

        'HAA'
        {
            @{ 
                Name     = 'HA App Labs'
                Id       = '855c22ce-7a6c-468b-ac72-1d1ef4355acf'
                TenantId = '11cb9e1b-bd08-4f80-bb8f-f71940c39079'
                State    = 'Enabled'
            }
        }
    }

    if ($Account)
    {
        if ($Auth)
        {
            Add-AzAccount -TenantId $AZ.TenantId -SubscriptionId $AZ.ID
        }
        else
        {
            Select-AzSubscription -Tenant $AZ.TenantId -SubscriptionId $AZ.ID
        }
    }
    else
    {
        Get-AzContext
    }
}