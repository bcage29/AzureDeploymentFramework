function New-Escape
{
    [CmdletBinding()]
    param (
        [Parameter()]
        [switch]$Regex,

        [Parameter(ValueFromRemainingArguments)]
        $String
        
    )

    if ($Regex)
    {
        $r = [regex]::Escape($String -join ' ')
    }
    else 
    {
        $r = ($String -join ' ') -replace '\\','/'
    }
    echo $r
}
new-alias -Name escapestring -Value New-Escape