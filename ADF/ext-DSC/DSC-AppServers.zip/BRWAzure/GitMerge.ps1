function GitMerge
{
    param (
        [validateset('main','dev')]
        [string]$DestBranch = 'main'
    )

    [string]$SourceBranch = switch ($DestBranch)
    {
        'main' {'dev'}
        'dev' {'main'}
    }
    

    git switch $DestBranch ; git pull ; git merge $SourceBranch ; git push ; git switch $SourceBranch
}
